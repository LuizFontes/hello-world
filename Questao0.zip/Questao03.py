import numpy as np


def maior_palindromo(palavra):
    for c in palavra:
        if c.isdigit() or len(palavra) == 1:
            print('Entrada invalida')
            return

    mat = np.zeros((len(palavra),len(palavra)))
    maior = ""
    # Tamanho da string = 1
    for i in range(0,len(palavra)):
        mat[i][i] = 1

    # Tamanho da string = 2
    for i in range(0,len(palavra)-1):
        if palavra[i] == palavra[i+1]:
            mat[i][i+1] = 1

    # Tamanho da string N > 2
    """Reaproveitaremos os ultimos resultados e verificaremos se é palindromo ou não. A regra consiste em
        testar a primeira e a ultima posição da palavra e reutilizar o resultado intermediario já encontrado."""
    for k in range(2,len(palavra)):
        for i in range(0, len(palavra)-k):
            j = i + k
            if ((palavra[i] == palavra[j]) and (mat[i+1][j-1] == 1)):
                mat[i][j] = 1
                maior = palavra[i:j+1]
    if maior == "":
        print('sem resultados')
    else:
        print(maior)


palavra = 'r4ta'
'''Definindo a quantidade T de cenários a serem testados'''
T = int(input('Insira a quantidade de cenários a serem testados: '))
j = 1
while j < T+1:
    palavra = input('Insira a {}º palavra: '.format(j))
    maior_palindromo(palavra.lower()) #evitar que ocorram erros com letras maiusculas/minusculas
    j= j+1


