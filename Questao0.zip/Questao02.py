'''Função que define se um número é perfeito ou não'''
def numero_perfeito(x):
    divisor = [] # Lista com os numeros divisores de X

    #Definindo os divisores de X
    if x == 0:
        print('{} não é um número perfeito'.format(x))
    else:
        for i in range(1 , x-1):
            if x % i == 0:
                divisor.append(i)
            i = i+1

        if sum(divisor) == x:
            print('{} é um número perfeito'.format(x))
        else:
            print('{} não é um número perfeito'.format(x))

'''Definindo a quantidade T de cenários a serem testados'''
T = int(input('Insira a quantidade de cenários a serem testados: '))

i = 1 #Definindo uma variavel auxiliar contadora
while i < T+1:
    x = int(input('Digite o {}° valor a ser lido: '.format(i)))
    if x>=1 and x<=108:
        numero_perfeito(x)
        i = i+1
    else:
        print('Numero invalido, repita o processo.')
