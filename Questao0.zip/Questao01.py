# Questão 1 - Fibonacci Array

'''Preenchendo um vetor com os 61 primeiros N valores da série de fibonacci.'''
''' X,Y e Z são variaveis auxiliares, criadas para aplicar a lógica de fibonacci.'''

fib = []
x = 0
y = 1

for i in range(1,61):
    z = x+y
    x = y
    y = z
    fib.append(y-x)


'''Definindo a quantidade T de cenários a serem testados'''
T = int(input('Insira a quantidade de cenários a serem testados: '))


'''Printando os valores de acordo com o pedido do usuario.'''
j = 1 #Definindo uma variavel auxiliar contadora
while j < T+1:
    x = int(input('Insira o {}º valor: '.format(j)))
    if x > i:
        print('Valor invalido, repita o processo.')
    else:
        print('Fib({}) = {}'.format(x,fib[x]))
        j = j+1
