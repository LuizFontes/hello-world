# Questão 6 - Big Bang Theory - Bazinga
# Importando algumas bibliotecas necessárias para o código.
import numpy as np
from enum import Enum

# Definindo uma classe e atribuindo valores numericos as opções do jogo.
class Jogo(Enum):
    pedra = 0
    papel = 1
    tesoura = 2
    lagarto = 3
    spock = 4

# Criando um dicionario com valores capazes de chamar a classe e retornar o seu valor numerico.
opcoes = { "pedra": Jogo.pedra,
           "papel": Jogo.papel,
           "tesoura": Jogo.tesoura,
           "lagarto": Jogo.lagarto,
           "spock": Jogo.spock
         }

# Criando uma matriz de possibilidades: 0 - Sheldom perdeu, 1 - Sheldom venceu, 2 - De novo!
matriz = np.array([(2,0,1,1,0),(1,2,0,0,1),(0,1,2,1,0),(0,1,0,2,1),(1,0,1,0,2)])

'''Definindo a quantidade T de cenários a serem testados'''
T = int(input('Insira a quantidade de cenários a serem testados: '))
for i in range(1,T+1,1):
    A = input(str('Digite a jogada de sheldon: '))
    B = input(str('Digite a jogada de Raj: '))

    if(matriz[opcoes[A].value][opcoes[B].value]) == 0:
        print('Caso #{}: Raj trapaceou!'.format(i))
    elif ((matriz[opcoes[A].value][opcoes[B].value])==1):
        print('Caso #{}: Bazinga!'.format(i))
    elif (matriz[opcoes[A].value][opcoes[B].value]) == 2:
        print('Caso #{}: De novo!'.format(i))


