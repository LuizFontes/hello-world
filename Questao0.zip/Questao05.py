#Questão 5 - Digits Count
# Criando um dicionario que irá armazenar a quantidade de vezes que determinado bit irá aparecer
soma = {
    "0": 0,
    "1": 0,
    "2": 0,
    "3": 0,
    "4": 0,
    "5": 0,
    "6": 0,
    "7": 0,
    "8": 0,
    "9": 0,
}
'''Definindo a quantidade T de cenários a serem testados'''
T = int(input('Insira a quantidade de cenários a serem testados: '))

j = 1 # Definindo variavel contadora
while j < T+1:
    A = input(str('\nDigite um numero: '))
    B = input(str('Digite outro numero: '))

    if A.isdigit() == True and B.isdigit() == True:

        for i in range(int(A), int(B) + 1):
            s = str(i)
            for c in s:
                soma[c] += 1

        for i in soma:
            print(soma[i], end =" ")

        for c in s:
            soma[c] = 0 # Zerando para iniciar a próxima contagem.
    else:
        print('Entrada invalida')
    j = j + 1
