
CREATE TABLE Cliente
(
id numeric
name varchar(255),
street VARCHAR (255),
city VARCHAR(255),
state CHAR (2),
credit_limit numeric,
PRIMARY KEY (id))

